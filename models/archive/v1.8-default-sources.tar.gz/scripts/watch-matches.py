#!/usr/bin/env python3
"""Live W/D/L monitor for versioned experiments (standard library only)."""
import argparse
import datetime
import json
from pathlib import Path
import sys
import time
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None


def display(config):
    stamp = datetime.datetime.now(ZoneInfo('Asia/Shanghai')).strftime('%H:%M:%S')
    lines = [f"Otello {config.get('version', 'v1')} 对局监控  {stamp}", '']
    for item in config['experiments']:
        paths = [ROOT / item['report']]
        if item.get('runtimeReport'):
            paths.insert(0, ROOT / item['runtimeReport'])
        result = {}
        for path in paths:
            result = read(path.with_suffix('.live.json')) or read(path) or {}
            if result:
                break
        counts = result.get('results', {})
        games = result.get('games', 0)
        planned = result.get('plannedGames', item['games'])
        state = '已完成' if result.get('complete') else ('进行中' if result else '排队中')
        if item.get('status') == 'stopped':state = '已停止'
        if result.get('experiment') in ('search-matrix', 'nnue-search-100ms', 'candidate-vs-approved-baseline'):
            lines.extend([item['name'],f'  {state}  {games}/{planned} 局  ({games/max(1,planned):.0%})'])
            if result.get('millisecondsPerMove'):
                lines.append(f"  每步 {result['millisecondsPerMove']}ms；交换黑白")
            for c in result['configs']:
                r=counts[c['id']]
                lines.append(f"  {c['name']}: 胜 {r['win']} 平 {r['draw']} 负 {r['loss']}，得分率 {r['scoreRate']:.1%}")
                if 'meanWallMs' in r:
                    unit='模拟' if r.get('searchUnit')=='simulations' else '节点'
                    lines.append(f"    平均子差 {r['meanDiscDifference']:+.2f}；平均耗时 {r['meanWallMs']:.1f}ms；{unit}/步 {r['meanSearchUnits']:,.0f}")
            elapsed=result.get('seconds',0)
            lines.append(f'  已用时 {int(elapsed)//60}分{int(elapsed)%60:02d}秒')
            current=result.get('currentGame')
            if current:
                lines.append(f"  当前第 {current['number']} 局，第 {current['ply']} 步")
                if 'blackCount' in current:
                    lines.append(f"  黑 {current['black']} {current['blackCount']} : {current['whiteCount']} 白 {current['white']}")
                    lines.append(f"  当前轮到{'黑' if current['turn']==1 else '白'}方；逐步更新")
                else:
                    lines.append(f"  黑 {current['black']} / 白 {current['white']}")
            elif not result.get('complete') and games<planned:
                lines.append(f'  第 {games+1} 局进行中；统计在每局结束后更新。')
            lines.append('');continue
        lines.extend([item['name'], f"  统计视角：{item['focus']}",
                      f"  {state}  {games}/{planned} 局    胜 {counts.get('win', 0)}  平 {counts.get('draw', 0)}  负 {counts.get('loss', 0)}"])
        if games:
            score = (counts.get('win', 0) + counts.get('draw', 0) / 2) / games
            lines.append(f'  得分率 {score:.1%}')
        if result.get('experiment') == 'book':
            hits = sum(v.get('bookHits', 0) for v in result.get('engines', {}).values())
            lines.append(f'  开局库命中 {hits} 次')
        current = result.get('currentGame')
        if current:
            lines.append(f"  当前第 {current['number']} 局，第 {current.get('ply', 0)} 步；黑 {current.get('black', 2)} / 白 {current.get('white', 2)}")
        lines.append('')
    lines.append('Ctrl+C 退出监控；对局会继续运行。')
    return '\n'.join(lines)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=ROOT / 'models/v1-experiments.json')
    parser.add_argument('--interval', type=float, default=1)
    parser.add_argument('--once', action='store_true')
    args = parser.parse_args()
    if args.interval <= 0:
        parser.error('--interval must be positive')
    try:
        while True:
            config = read(args.config)
            view = display(config) if config else '实验配置准备中…'
            if sys.stdout.isatty() and not args.once:
                print('\033[2J\033[H', end='')
            print(view, flush=True)
            if args.once:
                break
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print('\n监控已退出，对局不受影响。')
