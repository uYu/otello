#!/usr/bin/env python3
"""Compare candidate weights with the approved baseline using identical MCTS."""
import argparse
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('nnue_match', ROOT / 'scripts/compare-nnue-search.py')
match = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = match
spec.loader.exec_module(match)


def compare(args):
    if args.output.exists():
        raise ValueError('Choose a fresh output; reports are never overwritten')
    baseline = json.loads(args.baseline_manifest.read_text())
    learned=args.model.read_bytes()[:8]==b'OTNNUE3\0'
    configs = [dict(id='baseline', name=baseline['version'], search='mcts', model=baseline['defaultModel'],prior='uniform'),
               dict(id='candidate', name=args.label, search='mcts', model=str(args.model.resolve()),prior='learned' if learned else 'uniform')]
    assert match.sha(ROOT / configs[0]['model']) == baseline['modelSha256']
    match.CONFIGS = configs
    provenance = dict(version=args.label, experiment='candidate-vs-approved-baseline',
        baselineVersion=baseline['version'], baselineManifest=str(args.baseline_manifest),
        baselineManifestSha256=match.sha(args.baseline_manifest),
        configs=[dict(c, modelSha256=match.sha(ROOT / c['model'])) for c in configs],
        millisecondsPerMove=args.milliseconds, plannedGames=args.games, baseSeed=args.seed,
        openingPolicy=match.POLICY, start='initial', useBook=False,
        search='PUCT MCTS; per-config priors; exploration 1.5; reached-subtree reuse; maximum visits root choice',
        librarySha256=match.sha(args.library), runnerSha256=match.sha(__file__),
        baselineLibrarySha256=match.sha(args.baseline_library or args.library),
        sharedRunnerSha256=match.sha(ROOT / 'scripts/compare-nnue-search.py'),
        rulesSha256=match.sha(ROOT / 'scripts/compare-resnet.py'),
        policyAuditSha256=match.sha(ROOT / 'scripts/opening_policy.py'),
        sourceSha256={str(p.relative_to(ROOT)):match.sha(p) for p in sorted((ROOT/'cpp').rglob('*'))
                      if p.suffix in ('.cpp', '.hpp', '.h', '.inc')},
        platform=platform.platform(),
        limits='Paired colors and shared seeds from the initial board; repeated paths possible. No Elo inference.')
    records, engines = [], {}
    started = time.perf_counter()

    def save(complete=False):
        results, matrix = match.aggregate(records)
        report = dict(**provenance, complete=complete, games=len(records),
                      seconds=time.perf_counter()-started, results=results, matrix=matrix,
                      replayedActions=sum(len(g['moves']) for g in records), records=records)
        match.rules.write_json(args.output, report)
        live = dict(report)
        live.pop('records')
        match.rules.write_json(args.output.with_suffix('.live.json'), live)

    try:
        for c in configs:
            library=(args.baseline_library or args.library) if c['id']=='baseline' else args.library
            engines[c['id']] = match.Engine(library, c)
        save()
        for index in range(args.games):
            black, white = configs if index % 2 == 0 else configs[::-1]
            for engine in engines.values():
                engine.request(kind='clear')
            seed = (args.seed ^ ((index//2+1)*0x9e3779b9)) & 0x7fffffff
            board, turn = match.rules.initial(), 1
            moves, decisions = [], []
            while True:
                available = match.rules.legal(board, turn)
                if not available:
                    if not match.rules.legal(board, -turn):
                        break
                    move = -1
                else:
                    who = black['id'] if turn == 1 else white['id']
                    response = engines[who].request(kind='search', board=board, turn=turn,
                                                   seed=seed, ms=args.milliseconds)
                    decision = dict(ply=len(moves), turn=turn, engine=who, **response)
                    match.audit_decision(board, turn, decision)
                    decisions.append(decision)
                    move = response['move']
                board, turn = match.rules.play(board, turn, move)
                moves.append(move)
                assert len(moves) <= 120
            difference = sum(board)
            record = dict(number=index+1, black=black['id'], white=white['id'], seed=seed,
                openingPolicy=match.POLICY, opening=[], moves=moves, decisions=decisions,
                finalBoard=board, blackDiscDifference=difference,
                winner=black['id'] if difference > 0 else white['id'] if difference < 0 else None)
            match.replay(record)
            records.append(record)
            save()
            print(json.dumps(dict(completed=len(records), winner=record['winner'], difference=difference)), flush=True)
        assert match.sha(args.library) == provenance['librarySha256']
        assert match.sha(args.baseline_library or args.library) == provenance['baselineLibrarySha256']
        assert all(match.sha(ROOT/c['model']) == c['modelSha256'] for c in provenance['configs'])
        save(complete=True)
    finally:
        for engine in engines.values():
            engine.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--baseline-manifest', type=Path, default=ROOT / 'models/v1.7-default.json')
    parser.add_argument('--baseline-library', type=Path, help='Frozen v1.7 reference library, otherwise same as candidate')
    parser.add_argument('--label', default='v1.8-candidate')
    parser.add_argument('--library', type=Path, default=ROOT / ('.build/native/libothello.' + ('dylib' if sys.platform=='darwin' else 'so')))
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--games', type=int, default=100)
    parser.add_argument('--milliseconds', type=int, default=100)
    parser.add_argument('--seed', type=int, default=20261028)
    args = parser.parse_args()
    if args.games < 2 or args.games % 2 or not 1 <= args.milliseconds <= 60000:
        parser.error('Even games >=2 and milliseconds 1..60000 required')
    compare(args)
