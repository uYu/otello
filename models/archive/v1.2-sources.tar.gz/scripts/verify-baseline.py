#!/usr/bin/env python3
"""Check the published v1 model, sources, report checksums and W/D/L totals."""
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    baseline = json.loads((ROOT / 'models/v1-baseline.json').read_text())
    metadata = json.loads((ROOT / 'models/nnue256-v1.json').read_text())
    # v1 measurements stay frozen when the working tree advances to v1.1. Check
    # their original source bytes from the checksummed, reproducible snapshot.
    snapshot_path = ROOT / 'models/archive/v1-sources.json'
    sources = {}
    if snapshot_path.exists():
        snapshot = json.loads(snapshot_path.read_text())
        assert sha(ROOT / 'models/v1-baseline.json') == snapshot['baselineSha256']
        archive_path = ROOT / snapshot['archive']
        assert sha(archive_path) == snapshot['sha256']
        with tarfile.open(archive_path, 'r:gz') as archive:
            assert len(archive.getmembers()) == len(snapshot['files'])
            for name, expected in snapshot['files'].items():
                sources[name] = archive.extractfile(name).read()
                assert hashlib.sha256(sources[name]).hexdigest() == expected, name

    def source_sha(name):
        return hashlib.sha256(sources[name]).hexdigest() if sources else sha(ROOT / name)
    assert baseline['status'] == 'frozen'
    assert sha(ROOT / baseline['model']) == baseline['modelSha256'] == metadata['sha256']
    assert sha(ROOT / baseline['protocol']) == baseline['protocolSha256']
    assert source_sha('CMakeLists.txt') == baseline['cmakeSha256']
    assert all(source_sha(name) == value for name, value in baseline['sourceSha256'].items())
    assert source_sha('scripts/train-nnue.py') == metadata['trainingScriptSha256']
    total_games = book_hits = book_misses = 0
    for experiment in baseline['experiments']:
        path = ROOT / experiment['report']
        assert sha(path) == experiment['reportSha256']
        report = json.loads(path.read_text())
        assert report['complete'] and report['games'] == len(report['records']) == experiment['games']
        assert report['modelSha256'] == baseline['modelSha256']
        assert report['sourceSha256'] == baseline['sourceSha256']
        assert source_sha('scripts/compare-evaluators.py') == report['comparisonScriptSha256']
        counts = Counter()
        for game in report['records']:
            difference = game['modelDiscDifference']
            outcome = 'win' if difference > 0 else 'loss' if difference < 0 else 'draw'
            assert outcome == game['outcome']
            counts[outcome] += 1
            counts['discDifference'] += difference
            for decision in game['decisions']:
                if decision['bookProbe'] == 'hit':
                    assert decision['provider'] == 'book' and decision['nodes'] == 0
                    book_hits += 1
                elif decision['bookProbe'] == 'miss':
                    assert decision['provider'] == 'nnue'
                    book_misses += 1
        assert all(counts[k] == report['results'][k] == experiment['results'][k]
                   for k in ('win', 'draw', 'loss', 'discDifference'))
        total_games += report['games']
    assert total_games == 200 and book_hits == 893 and book_misses == 2107
    print(f'v1 verified: {total_games} games, frozen model/source snapshot, {book_hits} book hits, {book_misses} NNUE fallbacks')
    current_path = ROOT / 'models/v1.1-search-baseline.json'
    v11_sources = {}
    archive_manifest = ROOT / 'models/archive/v1.1-sources.json'
    if archive_manifest.exists():
        snapshot = json.loads(archive_manifest.read_text())
        assert sha(ROOT / 'models/v1.1-baseline.json') == snapshot['baselineSha256']
        assert sha(current_path) == snapshot['searchBaselineSha256']
        archive_path = ROOT / snapshot['archive']
        assert sha(archive_path) == snapshot['sha256']
        with tarfile.open(archive_path, 'r:gz') as archive:
            assert len(archive.getmembers()) == len(snapshot['files'])
            for name, expected in snapshot['files'].items():
                v11_sources[name] = archive.extractfile(name).read()
                assert hashlib.sha256(v11_sources[name]).hexdigest() == expected, name

    def v11_sha(name):
        return hashlib.sha256(v11_sources[name]).hexdigest() if v11_sources else sha(ROOT / name)

    if current_path.exists():
        current = json.loads(current_path.read_text())
        assert current['modelSha256'] == sha(ROOT / current['model'])
        assert all(v11_sha(name) == value for name, value in current['sourceSha256'].items())
        assert all(v11_sha(name) == value for name, value in current['artifactSha256'].items())
        assert all(row['allCandidateScoresEqual'] for row in current['benchmark']['results'])
        print('v1.1 search verified: frozen source snapshot and model match the performance baseline')
    release_path = ROOT / 'models/v1.1-baseline.json'
    if release_path.exists():
        release = json.loads(release_path.read_text())
        assert release['version'] == 'v1.1' and release['status'] == 'frozen'
        assert release['modelSha256'] == baseline['modelSha256']
        assert all(v11_sha(name) == value for name, value in release['sourceSha256'].items())
        assert sha(current_path) == release['searchBaselineSha256']
        entry = release['strengthReport']
        assert sha(ROOT / entry['path']) == entry['sha256']
        report = json.loads((ROOT / entry['path']).read_text())
        assert report['complete'] and report['version'] == 'v1.1'
        assert report['games'] == report['plannedGames'] == len(report['records']) == 100
        assert report['start'] == 'initial' and report['opening'] == [] and not report['useBook']
        assert report['millisecondsPerMove'] == 50 and report['maxDepth'] == 64
        assert report['modelSha256'] == release['modelSha256']
        assert report['librarySha256'] == release['librarySha256']
        assert report['sourceSha256']['v1'] == baseline['sourceSha256']
        assert all(v11_sha(name) == value for name, value in report['sourceSha256']['v1.1'].items())
        runner = ROOT / 'scripts/compare-versions.py'
        assert sha(runner) == report['runnerSha256']
        spec = importlib.util.spec_from_file_location('version_comparison', runner)
        comparison = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(comparison)
        counts, actions = Counter(), 0
        for i, game in enumerate(report['records']):
            assert game['number'] == i + 1 and game['focusSide'] == (1 if i % 2 == 0 else -1)
            assert game['opening'] == []
            actions += comparison.replay(game)
            counts[game['outcome']] += 1
            counts['discDifference'] += game['focusDiscDifference']
        assert all(counts[k] == report['results'][k] == entry['results'][k]
                   for k in ('win', 'draw', 'loss', 'discDifference'))
        assert report['replayedGames'] == 100 and actions == report['replayedActions']
        assert report['uniqueTranscripts'] == len({tuple(game['moves']) for game in report['records']})
        assert report['scoreRate'] == entry['scoreRate'] == (counts['win'] + counts['draw'] / 2) / 100
        print(f'v1.1 strength verified: 100 initial-position games, {actions} replayed actions, equal 50 ms budget')
    new_path = ROOT / 'models/v1.2-baseline.json'
    if new_path.exists():
        release = json.loads(new_path.read_text())
        assert release['version'] == 'v1.2' and release['status'] == 'frozen'
        assert all(sha(ROOT / name) == value for name, value in release['sourceSha256'].items())
        assert all(sha(ROOT / name) == value for name, value in release['artifactSha256'].items())
        model = json.loads((ROOT / release['modelMetadata']).read_text())
        assert model['sha256'] == release['modelSha256'] == sha(ROOT / release['model'])
        assert model['modelFormat'] == 2 and model['parameters'] == 33537
        assert model['dataset']['cacheSha256'] == metadata['dataset']['cacheSha256']
        assert model['trainingScriptSha256'] == sha(ROOT / 'scripts/train-nnue.py')
        assert model['cppParityPositions'] == 1024
        entry = release['strengthReport']
        assert sha(ROOT / entry['path']) == entry['sha256']
        report = json.loads((ROOT / entry['path']).read_text())
        assert report['complete'] and report['version'] == 'v1.2'
        assert report['games'] == report['plannedGames'] == len(report['records']) == 100
        assert report['start'] == 'initial' and report['opening'] == [] and not report['useBook']
        assert report['millisecondsPerMove'] == 50 and report['maxDepth'] == 64
        assert report['modelSha256'] == {'v1.1': baseline['modelSha256'], 'v1.2': release['modelSha256']}
        assert report['librarySha256'] == release['librarySha256']
        old_release = json.loads((ROOT / 'models/v1.1-baseline.json').read_text())
        assert report['sourceSha256']['v1.1'] == old_release['sourceSha256']
        assert all(sha(ROOT / name) == value for name, value in report['sourceSha256']['v1.2'].items())
        runner = ROOT / 'scripts/compare-model-versions.py'
        assert sha(runner) == report['runnerSha256']
        spec = importlib.util.spec_from_file_location('model_comparison', runner)
        comparison = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(comparison)
        counts, actions = Counter(), 0
        for i, game in enumerate(report['records']):
            assert game['number'] == i + 1 and game['focusSide'] == (1 if i % 2 == 0 else -1)
            assert game['opening'] == []
            actions += comparison.replay(game)
            counts[game['outcome']] += 1
            counts['discDifference'] += game['focusDiscDifference']
        assert all(counts[k] == report['results'][k] == entry['results'][k]
                   for k in ('win', 'draw', 'loss', 'discDifference'))
        assert report['replayedGames'] == 100 and actions == report['replayedActions']
        assert report['uniqueTranscripts'] == len({tuple(game['moves']) for game in report['records']})
        assert report['scoreRate'] == entry['scoreRate'] == (counts['win'] + counts['draw'] / 2) / 100
        print(f'v1.2 verified: turn-aware model, same frozen dataset, 100 games, {actions} replayed actions')


if __name__ == '__main__':
    verify()
